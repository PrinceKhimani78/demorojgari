import React from "react";

const Resumeupload = () => {
  return (
    <>
      <h1>Resume Upload</h1>
    </>
  );
};

export default Resumeupload;
