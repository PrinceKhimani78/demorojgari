import React from "react";

const Postjob = () => {
  return (
    <>
      <h1>Post Job</h1>
    </>
  );
};

export default Postjob;
