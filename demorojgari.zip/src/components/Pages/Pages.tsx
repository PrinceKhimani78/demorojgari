import React from "react";

const Pages = () => {
  return (
    <div>
      <h1>hii</h1>
    </div>
  );
};

export default Pages;
