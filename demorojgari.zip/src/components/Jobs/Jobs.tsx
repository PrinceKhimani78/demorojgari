import React from "react";
import Grid from "./Grid/Grid";

const Jobs = () => {
  return (
    <div>
      <Grid />
    </div>
  );
};

export default Jobs;
