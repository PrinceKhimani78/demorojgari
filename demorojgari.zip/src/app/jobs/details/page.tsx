import Details from "@/components/Jobs/Details/Details";

export default Details