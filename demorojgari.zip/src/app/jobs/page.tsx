import Jobs from "@/components/Jobs/Jobs";

export default Jobs;
