import Appliedjobs from "@/components/Candidates/Applied-jobs/Applied-jobs";
export default Appliedjobs;
