import Changepassword from "@/components/Candidates/Change-password/Change-password";
export default Changepassword;
