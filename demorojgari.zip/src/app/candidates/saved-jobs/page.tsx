import Savedjobs from "@/components/Candidates/Saved-jobs/Saved-jobs";
export default Savedjobs;
