import Candidates from "@/components/Candidates/Candidates";

export default Candidates