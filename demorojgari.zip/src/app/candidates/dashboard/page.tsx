import Dashbord from "@/components/Candidates/Dashbord/Dashbord";
export default Dashbord;
