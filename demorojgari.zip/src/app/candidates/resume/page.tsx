import Resume1 from "@/components/Candidates/Resume/Resume1";
export default Resume1;
