import Login from "@/components/Candidates/Login/Login";
export default Login;
