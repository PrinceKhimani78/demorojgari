import JobAlerts from "@/components/Candidates/Job-Alerts/Job-Alerts";
export default JobAlerts;
