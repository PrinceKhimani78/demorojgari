import Profile from "@/components/Candidates/Profile/Profile";
export default Profile;
