import Postjob from "@/components/Admin/Post-job/Post-job";
export default Postjob;
