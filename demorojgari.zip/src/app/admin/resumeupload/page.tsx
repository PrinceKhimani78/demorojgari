import Resumeupload from "@/components/Admin/Resumeupload/Resumeupload";
export default Resumeupload;
