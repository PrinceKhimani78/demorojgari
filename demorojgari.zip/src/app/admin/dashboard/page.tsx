import Dashboard from "@/components/Admin/Dashboard/Dashboard";
export default Dashboard;
