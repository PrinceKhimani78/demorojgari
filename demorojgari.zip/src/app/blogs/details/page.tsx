import Details from "@/components/Blogs/Details/Details";
export default Details;
