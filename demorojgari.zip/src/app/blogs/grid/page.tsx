import Grid from "@/components/Blogs/Grid/Grid";
export default Grid;
