import Blogs from "@/components/Blogs/Blogs";

export default Blogs;
