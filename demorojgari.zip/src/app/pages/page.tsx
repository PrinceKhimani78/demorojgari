import Pages from "@/components/Pages/Pages";
export default Pages;
