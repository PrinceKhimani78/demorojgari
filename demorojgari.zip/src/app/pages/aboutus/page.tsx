import AboutUs from "@/components/Pages/AboutUs/AboutUs";
import React from "react";

const Page = () => {
  return (
    <>
      <AboutUs />
    </>
  );
};
export default Page;
