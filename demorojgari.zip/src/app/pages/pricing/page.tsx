import Pricing from "@/components/Pages/Pricing/Pricing";
export default Pricing;
