import Recruiters from "@/components/Recruiters/Recruiters";

export default Recruiters