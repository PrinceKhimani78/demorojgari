import Packages from "@/components/Recruiters/Packages/Packages";
export default Packages;
