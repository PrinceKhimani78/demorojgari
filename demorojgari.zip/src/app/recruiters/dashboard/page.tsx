import Dashboard from "@/components/Recruiters/Dashboard/Dashboard";
export default Dashboard;
