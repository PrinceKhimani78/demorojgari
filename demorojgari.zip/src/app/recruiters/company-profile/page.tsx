import Companyprofile from "@/components/Recruiters/Company-Profile/Company-profile";
export default Companyprofile;
