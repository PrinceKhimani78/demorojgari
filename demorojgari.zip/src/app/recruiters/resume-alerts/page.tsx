import Resumealerts from "@/components/Recruiters/Resume-alerts/Resume-alerts";
export default Resumealerts;
