import Candidateslist from "@/components/Recruiters/Candidates-list/Candidates-list";
export default Candidateslist;
