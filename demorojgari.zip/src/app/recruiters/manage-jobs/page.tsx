import Managejobs from "@/components/Recruiters/Manage-jobs/Manage-jobs";
export default Managejobs;
