import Postjob from "@/components/Recruiters/Post-job/Post-job";
export default Postjob;
